/**
 * Created by Danepliz on 2/4/16.
 */


(function(){

    window.news = {};

})();
