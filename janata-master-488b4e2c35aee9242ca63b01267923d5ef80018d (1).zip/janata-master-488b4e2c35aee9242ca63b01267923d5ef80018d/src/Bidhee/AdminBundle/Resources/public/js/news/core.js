/**
 * Created by Danepliz on 2/4/16.
 */

;
(function(ns){

    'use strict';

    ns.core = {};

})(news);
