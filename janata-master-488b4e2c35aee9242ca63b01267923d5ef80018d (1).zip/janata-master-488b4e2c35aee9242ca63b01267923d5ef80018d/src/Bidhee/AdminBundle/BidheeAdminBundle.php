<?php

namespace Bidhee\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeAdminBundle extends Bundle
{
}
