<?php

namespace Bidhee\FrontendBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeFrontendBundle extends Bundle
{
}
