<?php

namespace Bidhee\FoundationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeFoundationBundle extends Bundle
{
}
