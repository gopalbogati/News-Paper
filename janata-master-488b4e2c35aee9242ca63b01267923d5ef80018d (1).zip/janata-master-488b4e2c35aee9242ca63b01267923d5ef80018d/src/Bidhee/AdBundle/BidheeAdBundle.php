<?php

namespace Bidhee\AdBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeAdBundle extends Bundle
{
}
