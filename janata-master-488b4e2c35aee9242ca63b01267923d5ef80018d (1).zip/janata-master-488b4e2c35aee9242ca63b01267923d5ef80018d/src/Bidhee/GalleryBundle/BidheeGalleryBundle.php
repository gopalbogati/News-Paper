<?php

namespace Bidhee\GalleryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeGalleryBundle extends Bundle
{
}
