<?php

namespace Bidhee\EpaperBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class EpaperControllerTest extends WebTestCase
{
}
