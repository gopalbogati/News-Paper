<?php

namespace Bidhee\EpaperBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EpaperBundle extends Bundle
{
}
