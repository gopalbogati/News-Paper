<?php

namespace Bidhee\NewsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeNewsBundle extends Bundle
{
}
