<?php

namespace Bidhee\NewsBundle\Jobs;

use BCC\ResqueBundle\Job;

class NotificationJob extends Job
{
    public function run($args)
    {

    }
}
