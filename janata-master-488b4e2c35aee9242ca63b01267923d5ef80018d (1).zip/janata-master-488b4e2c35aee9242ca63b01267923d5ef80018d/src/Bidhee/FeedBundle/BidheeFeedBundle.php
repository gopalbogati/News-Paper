<?php

namespace Bidhee\FeedBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeFeedBundle extends Bundle
{
}
