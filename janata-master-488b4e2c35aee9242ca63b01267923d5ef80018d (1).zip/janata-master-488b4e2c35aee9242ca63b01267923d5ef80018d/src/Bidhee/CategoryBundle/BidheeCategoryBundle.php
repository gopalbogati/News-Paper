<?php

namespace Bidhee\CategoryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeCategoryBundle extends Bundle
{
}
