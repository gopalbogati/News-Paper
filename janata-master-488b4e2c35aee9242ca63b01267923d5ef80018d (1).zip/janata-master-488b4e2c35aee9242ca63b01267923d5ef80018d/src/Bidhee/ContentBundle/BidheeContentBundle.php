<?php

namespace Bidhee\ContentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeContentBundle extends Bundle
{
}
