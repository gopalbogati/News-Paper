<?php

namespace Bidhee\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BidheeUserBundle extends Bundle
{

}
